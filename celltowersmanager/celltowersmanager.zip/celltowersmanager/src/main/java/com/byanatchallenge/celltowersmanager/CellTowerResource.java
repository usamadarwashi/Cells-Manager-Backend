package com.byanatchallenge.celltowersmanager;

import com.byanatchallenge.celltowersmanager.model.CellTower;
import com.byanatchallenge.celltowersmanager.service.CellTowerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cellTower")
public class CellTowerResource {
    private final CellTowerService cellTowerService;

    public CellTowerResource(CellTowerService cellTowerService) {
        this.cellTowerService = cellTowerService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<CellTower>> getAllCellTowers(){
        List<CellTower> cellTowers = cellTowerService.findAllCellTowers();
        return new ResponseEntity<>(cellTowers, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<CellTower> getCellTowerById(@PathVariable("id") Long id){
        CellTower cellTower = cellTowerService.findCellTowerById(id);
        return new ResponseEntity<>(cellTower, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<CellTower> addCellTower(@RequestBody CellTower cellTower){
        CellTower newCellTower = cellTowerService.addCellTower(cellTower);
        return new ResponseEntity<>(newCellTower, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<CellTower> updateCellTower(@RequestBody CellTower cellTower){
        CellTower updateCellTower = cellTowerService.updateCellTower(cellTower);
        return new ResponseEntity<>(updateCellTower, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteCellTower(@PathVariable("id") Long id){
        cellTowerService.deleteCellTower(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/find/{id}/isItThere")
    public ResponseEntity<Boolean> checkCellTowerById(@PathVariable("id") Long id){
        CellTower cellTower = cellTowerService.findCellTowerById(id);

        if (cellTower != null) {
            return new ResponseEntity<>(true, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(false, HttpStatus.OK);
        }
    }






}
