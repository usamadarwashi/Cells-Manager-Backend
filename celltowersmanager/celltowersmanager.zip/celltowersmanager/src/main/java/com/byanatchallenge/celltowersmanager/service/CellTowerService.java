package com.byanatchallenge.celltowersmanager.service;

import com.byanatchallenge.celltowersmanager.exception.CellTowerNotFoundException;
import com.byanatchallenge.celltowersmanager.model.CellTower;
import com.byanatchallenge.celltowersmanager.repo.CellTowerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CellTowerService {
    private final CellTowerRepo cellTowerRepo;

    @Autowired
    public CellTowerService(CellTowerRepo cellTowerRepo) {
        this.cellTowerRepo = cellTowerRepo;
    }
    public CellTower addCellTower(CellTower cellTower){
        cellTower.setAddress(UUID.randomUUID().toString());
        return cellTowerRepo.save(cellTower);
    }
    public List<CellTower> findAllCellTowers(){
        return cellTowerRepo.findAll();
    }
    public CellTower updateCellTower(CellTower cellTower){
        return cellTowerRepo.save(cellTower);
    }
    public CellTower findCellTowerById(Long id){
        return cellTowerRepo.findCellTowerById(id);
    }
    public void deleteCellTower(Long id){
         cellTowerRepo.deleteCellTowerById(id);
    }

//    public CellTower checkCellTowerById(Long id){
//
//
//
//        return null;
//    }

    }


