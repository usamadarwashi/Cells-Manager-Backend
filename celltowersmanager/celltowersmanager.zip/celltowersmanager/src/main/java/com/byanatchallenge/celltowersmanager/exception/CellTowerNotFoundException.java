package com.byanatchallenge.celltowersmanager.exception;

public class CellTowerNotFoundException extends RuntimeException {
    public CellTowerNotFoundException(String message) {
        super(message);
    }
}
